<!DOCTYPE html>

<html>
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Admin | Employee's Payroll Management System</title>
 	

<?php
	session_start();
  if(!isset($_SESSION['login_id']))
    header('location:login.php');
 include('./header.php'); 
 // include('./auth.php'); 
 ?>
<style>
body {
 background-image: linear-gradient(black, pink);
 background-repeat: no-repeat;
  background-size: cover;
}
  .modal-dialog.large {
    width: 80% !important;
    max-width: unset;
  }
  .modal-dialog.mid-large {
    width: 50% !important;
    max-width: unset;
  }
  div#confirm_modal {
      z-index: 9991;
  }

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);
  margin: 8px;
}



.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
</style>
</head>
<body>
	<?php include 'topbar.php' ?>
	<?php include 'navbar.php' ?>
	
  <div class="toast" id="alert_toast" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-body text-white">
    </div>
  </div>
  <center>
  <main id="view-panel" >
  	



<div class="row">
  <div class="column" style=" margin: 0 auto; /* Added */
        float: none; /* Added */
        margin-bottom: 10px; /* Added */">
    <div class="card" >


               <h2><strong>FAQ</strong></h2>
  <p>
<h5>Log In and Log Out.</h5>
<h5>▪ Username and Password </h5>
Authentication Function of admin and users
<h5>▪ Homepage of the System</h5> 
The first page when you log in
<h5>▪ Attendance</h5> 
Adding Attendance List, Date, Employee Number, Full Name, Time Record,
Time In, Time Out
<h5>▪ Payroll List</h5> 
Add New Payroll, Ref From, Date From, Date To, Status, Calculate
View Edit, Delete, Show Entries.
<h5>▪ Employee List</h5> 
Employee Number, First Name, Middle Name, Last Name
Department, Position, View, Edit, Delete, Show Entries, and Add Employee.
<h5>▪ Department List</h5>
Department Form, Name, Number of Entries, Description
Edit, and Delete.
<h5>▪ Positions</h5> 
Position Form, Department, Name, Number of Entries, Position
Edit, Delete.
<h5>▪ Allowance List</h5>
Allowance Form, Number of Entries
Edit, and Delete.
<h5>▪ Deduction of salary list</h5> 
Deduction Form, Deduction Name, Number of Entries
Edit, and Delete.
<h5>▪ Manage Users</h5>

</p>
      </div>
    </div>
  </div>


</div>

</body>
</html>
