<?php include('./db_connect.php'); ?>
<?php


// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
$username = $_POST['username'];
	 $name = $_POST['name'];
	 $password = $_POST['password'];
	  $contact = $_POST['contact'];

$sql = "INSERT INTO users (username, name, password, contact)
 VALUES ('$username','$name','$password','$contact')";

if ($conn->query($sql) === TRUE) {
  include 'login.php';
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
?>


