<!DOCTYPE html>

<html>
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Admin | Employee's Payroll Management System</title>
 	

<?php
	session_start();
  if(!isset($_SESSION['login_id']))
    header('location:login.php');
 include('./header.php'); 
 // include('./auth.php'); 
 ?>
<style>
body {
 background-image: linear-gradient(black, pink);
 background-repeat: no-repeat;
  background-size: cover;
}
  .modal-dialog.large {
    width: 80% !important;
    max-width: unset;
  }
  .modal-dialog.mid-large {
    width: 50% !important;
    max-width: unset;
  }
  div#confirm_modal {
      z-index: 9991;
  }

html {
  box-sizing: border-box;
}

*, *:before, *:after {
  box-sizing: inherit;
}

.column {
  float: left;
  width: 33.3%;
  margin-bottom: 16px;
  padding: 0 8px;
}

.card {
  box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2);

}



.container {
  padding: 0 16px;
}

.container::after, .row::after {
  content: "";
  clear: both;
  display: table;
}

.title {
  color: grey;
}

.button {
  border: none;
  outline: 0;
  display: inline-block;
  padding: 8px;
  color: white;
  background-color: #000;
  text-align: center;
  cursor: pointer;
  width: 100%;
}

.button:hover {
  background-color: #555;
}

@media screen and (max-width: 650px) {
  .column {
    width: 100%;
    display: block;
  }
}
</style>
</head>
<body>
	<?php include 'topbar.php' ?>
	<?php include 'navbar.php' ?>
	
  <div class="toast" id="alert_toast" role="alert" aria-live="assertive" aria-atomic="true">
    <div class="toast-body text-white">
    </div>
  </div>
  <center>
  <main id="view-panel" >

  	



<div class="row">
  <div class="column">
    <div class="card"  style="width:100%">
      <img src="cobra.jpg" alt="Cobrador" style="width:100%">
      <div class="container">
        <h2>Adrian Cobrador</h2>
        <p class="title">Administrator</p>
        <p>This payroll system is an important tool, but it is also a software-based system that is efficient. This will 
		include everything that has to do with the payment of the employee as well as other financial matters within the 
		organisation. This scheme also includes tasks such as keeping track of salaries, recording hours 
		(including overtime and holidays), and making other deductions. It has been extremely successful to have 
		this system in place to assist business owners in maintaining greater control over the payroll process.</p>
        <p>Email: cobrador.ad@gmail.com</p>
      </div>
    </div>
  </div>


    <div>
      <img src="heaven.gif" alt="Cobrador" style="width:150%;">

    </div>
  </div>

</div>

</body>
</html>
