<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Admin | Employee's Payroll Management System</title>
 	

<?php include('./header.php'); ?>
<?php include('./db_connect.php'); ?>
<?php 
session_start();
if(isset($_SESSION['login_id']))
header("location:index.php?page=home");

?>

</head>
<!--css-->
<style>
	body{
		width: 100%;
	    height: calc(100%);
	   background: url(heaven.jpg);
	    background-repeat: no-repeat;
	    background-size: cover;
	}
	main#main{
		border-radius: 10px;
		width:100%;
		height: calc(100%);
		background:white;
		
	}
	#login-right{
		
		opacity:0.8;
		margin-top:5%;
		margin-right: 15%;
		margin-left: 15%;
		height: calc(100%);
		align-items: center;

	}

	#login-right .card{
		
		margin: auto;
		z-index: 1
	}
.logo {
    margin: auto;
    font-size: 8rem;
    background: white;
    padding: .5em 0.7em;
    border-radius: 50% 50%;

    z-index: 10;
}
div#login-right::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: calc(100%);
    height: calc(100%);

}
.form-control {
    display: block;
    width: 69%;
	margin-left: 15%;
    height: calc(1.5em + .75rem + 2px);
    padding: .375rem .75rem;
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 0.1px solid black;
    border-radius: .25rem;
    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
}

</style>

<body>





  		<div id="login-right" >
  			<div class="card col-md-8" >
  				<div class="card-body">
  						
  					<form id="login-form" >
  						<div class="form-group">
					<center>
						<h4><strong> Cobra Inc. Payroll Management System </strong></h4>
						</center>
						<br><br>
  							<label for="username" style="margin-left: 15%;"  class="control-label">Company Username</label>
  							<input type="text" id="username" name="username" class="form-control">
  						</div>
  						<div class="form-group">
  							<label for="password"  style="margin-left: 15%;" class="control-label">Assigned Password</label>
  							<input type="password" id="password" name="password" class="form-control">
  						</div>
  						<center><button class="btn-sm btn-block btn-wave col-md-4 btn-primary">Login</button></center>
						
  					</form>
					 <div>
   <center><a href="register.php"><button class="btn-sm btn-block btn-wave col-md-4 btn-primary" >Signup</button></a></center>
   </div>
  				</div>
  			</div>
  		</div>
  



  <a href="#" class="back-to-top"><i class="icofont-simple-up"></i></a>


</body>
<script>
	$('#login-form').submit(function(e){
		e.preventDefault()
		$('#login-form button[type="button"]').attr('disabled',true).html('Logging in...');
		if($(this).find('.alert-danger').length > 0 )
			$(this).find('.alert-danger').remove();
		$.ajax({
			url:'ajax.php?action=login',
			method:'POST',
			data:$(this).serialize(),
			error:err=>{
				console.log(err)
		$('#login-form button[type="button"]').removeAttr('disabled').html('Login');

			},
			success:function(resp){
				if(resp == 1){
					location.href ='index.php?page=home';
				}else if(resp == 2){
					location.href ='voting.php';
				}else{
					$('#login-form').prepend('<div class="alert alert-danger">Username or password is incorrect.</div>')
					$('#login-form button[type="button"]').removeAttr('disabled').html('Login');
				}
			}
		})
	})
</script>	
</html>