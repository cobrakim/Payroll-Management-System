<?php include('./header.php'); ?>
<?php include('./db_connect.php'); ?>
<?php  
session_start(); 
if(isset($_SESSION['login_id']))
{
	header("location:index.php");
}
else{
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Register</title>

</head>
<!--css-->
<style>
	body{
		width: 100%;
	    height: calc(100%);
	   background: url(heaven.jpg);
	    background-repeat: no-repeat;
	    background-size: cover;
	}
	main#main{
		border-radius: 10px;
		width:100%;
		height: calc(100%);
		background:white;
		
	}
	#login-right{
		
		opacity:0.8;
		margin-top:5%;
		margin-right: 15%;
		margin-left: 15%;
		height: calc(100%);
		align-items: center;

	}

	#login-right .card{
		
		margin: auto;
		z-index: 1
	}
.logo {
    margin: auto;
    font-size: 8rem;
    background: white;
    padding: .5em 0.7em;
    border-radius: 50% 50%;

    z-index: 10;
}
div#login-right::before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: calc(100%);
    height: calc(100%);

}
.form-control {
    display: block;
    width: 69%;
	margin-left: 15%;
    height: calc(1.5em + .75rem + 2px);
    padding: .375rem .75rem;
    font-size: 1rem;
    font-weight: 400;
    line-height: 1.5;
    color: #495057;
    background-color: #fff;
    background-clip: padding-box;
    border: 0.1px solid black;
    border-radius: .25rem;
    transition: border-color .15s ease-in-out,box-shadow .15s ease-in-out;
}

</style>
  

<center>
<body>


		<div id="login-right" >
  			<div class="card col-md-8" >
  				<div class="card-body">
      <form method="post" action="regcon.php" >
        <div  class="form-group">
          <div class="form-group">
            <h4>Register for Users</h4>

          </div>
        </div>
        <div  class="form-group">
          <div class="card-body">
            <i class="mdi-social-person-outline prefix"></i>
			 <label for="username" class="left-align" >Username</label><br>
            <input name="username" id="username" type="text"  data-error=".errorTxt1"  required>
           
			<div class="errorTxt1"></div>			
         
    
          <div class="input-field col s12">
            <i class="mdi-social-person prefix"></i>
			<label for="name" class="left-align">Name</label><br>
            <input name="name" id="name" type="text" data-error=".errorTxt2"  required>
            
			<div class="errorTxt2"></div>			
         
        </div>
        <div class="row margin">
          <div class="input-field col s12">
            <i class="mdi-action-lock-outline prefix"></i>
			<label for="password">Password</label><br>
            <input name="password" id="password" type="password" data-error=".errorTxt3"  required>
            
			<div class="errorTxt3"></div>			
          </div>
        </div>
        <div class="row margin">
          <div class="input-field col s12">
            <i class="mdi-communication-phone prefix"></i>
			<label for="phone">Phone</label><br>
            <input name="contact" id="phone" type="number" data-error=".errorTxt4"  required>
            <br>
			<div class="errorTxt4"></div>			
          </div>
        </div>		
        <div class="row">
          <div class="input-field col s12">
		  <br>
			<button onclick="myFunction()" onclick="submit" onclick="" class="btn-sm btn-block btn-wave col-md-4 btn-primary" >Login</button>
          </div>
          
        </div>
      </form>
	  <div class="input-field col s12">
            <p class="margin center medium-small sign-up" >Already have an account? <a href="login.php" >Login</a></p>
          </div>
    </div>
  </div>
<script>
function myFunction() {
  alert("Successfully Registered");
}
</script>

    <script type="text/javascript">
    $("#formValidate").validate({
        rules: {
            username: {
                required: true,
                minlength: 5
            },
            name: {
                required: true,
                minlength: 5				
            },
			password: {
				required: true,
				minlength: 5
			},
            phone: {
				required: true,
				minlength: 4
			},
        },
        messages: {
            username: {
                required: "Enter username",
                minlength: "Minimum 5 characters are required."
            },
            name: {
                required: "Enter name",
                minlength: "Minimum 5 characters are required."
            },
			password: {
				required: "Enter password",
				minlength: "Minimum 5 characters are required."
			},
            phone:{
				required: "Specify contact number.",
				minlength: "Minimum 4 characters are required."
			},		
        },
        errorElement : 'div',
        errorPlacement: function(error, element) {
          var placement = $(element).data('error');
          if (placement) {
            $(placement).append(error)
          } else {
            error.insertAfter(element);
          }
        }
     });
    </script>
</body>
</html>
<?php
}
?>